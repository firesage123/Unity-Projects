using UnityEngine;

/// <summary>
/// Destroys wayward objects that run into it.
/// </summary>
public class WallOfDeath : MonoBehaviour {
    
    // Collison with any object
    internal void OnTriggerEnter2D(Collider2D worldObject) {
        if (worldObject.tag == "Tank") 
            ScoreManager.IncreaseScore(worldObject.gameObject, -50);
        Destroy(worldObject.gameObject);
    }
}
